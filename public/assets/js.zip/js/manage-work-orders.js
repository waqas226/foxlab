'use strict';

$(function () {
  // Variable declaration for table
  var dt_user_table = $('.datatables-work');

  // Users datatable
  // if (dt_user_table.length)
  var dt_user = dt_user_table.DataTable({
    processing: true,
    serverSide: true,

    ajax: {
      url: '/manage-work-orders/show',
      type: 'GET',
      data: function (d) {
        // Add any additional parameters to the request here
        d.status = $('#FilterTransaction').val() || 'Open'; // Get the selected status from the filter
        d.company_id = $('#workCompany').val() || ''; // Get the selected company from the filter
      }
    },
    // assetsPath + 'json/user-list.json', // JSON file to add data
    columns: [
      // columns according to JSON
      { data: '' },
      // { data: 'id' },
      // { data: 'username' },
      { data: 'company' },
      { data: 'address' },
      { data: 'devices' },
      { data: 'date_added' },
      { data: 'status' },
      { data: 'action' }
    ],
    columnDefs: [
      {
        // For Responsive
        className: 'control',
        searchable: false,
        orderable: false,
        responsivePriority: 2,
        targets: 0,
        render: function (data, type, full, meta) {
          return '';
        }
      },

      {
        // Plans
        targets: 1,
        responsivePriority: 1,
        render: function (data, type, full, meta) {
          var $company = full['customer'];

          return '<span class="fw-medium">' + ($company ? $company.company : '') + '</span>';
        }
      },
      {
        // Plans
        targets: 2,
        responsivePriority: 2,
        render: function (data, type, full, meta) {
          var $company = full['customer'];

          return '<span class="fw-medium">' + ($company ? $company.address : '') + '</span>';
        }
      },

      //extra mail
      {
        // Plans
        targets: 3,
        render: function (data, type, full, meta) {
          var $devices = full['devices'].length;

          return '<span class="fw-medium text-capitalized" >' + $devices + '</span>';
        }
      },
      {
        // User Status
        targets: 4,
        responsivePriority: 3,
        render: function (data, type, full, meta) {
          var $date = full['created_at'];
          // var $date = '11 Jan 2025 <br> 10:45:17 AM';
          return moment($date).format('YYYY-MM-DD hh:mm:ss A');
        }
      },

      {
        // User Status
        targets: 5,
        render: function (data, type, full, meta) {
          var $status = full['status'];
          // enum('Open', 'Closed', 'Archived', 'Pending'), select option for these statuses
          var $output =
            '<select class="form-select text-capitalize update-status" data-id="' +
            full['id'] +
            '" id="status" name="status" aria-label="Status">' +
            '<option value="Open"' +
            ($status === 'Open' ? ' selected' : '') +
            '>Open</option>' +
            '<option value="Closed"' +
            ($status === 'Closed' ? ' selected' : '') +
            '>Closed</option>' +
            '<option value="Archived"' +
            ($status === 'Archived' ? ' selected' : '') +
            '>Archived</option>' +
            '<option value="Pending"' +
            ($status === 'Pending' ? ' selected' : '') +
            '>Pending</option>' +
            '</select>';
          return $output;
        }
      },
      {
        // Actions
        targets: -1,
        title: 'Actions',
        searchable: false,
        orderable: false,
        render: function (data, type, full, meta) {
          var id = full['id'];
          var loc = "'/manage-work-orders/print/" + id + "','Print','width=650,height=650'";
          return (
            '<div class="d-flex align-items-center text-secondary">' +
            '<a href="javascript:;" onclick="window.open(' +
            loc +
            ');" class="text-secondary print-record"><i class="ti ti-printer ti-sm me-2"></i></a>' +
            '<a href="/manage-work-orders/' +
            id +
            '/edit" class="text-primary"><i class="ti ti-edit ti-sm me-2"></i></a>' +
            '<a href="manage-work-orders/' +
            id +
            '" class="text-body open-record"><i class="ti ti-list ti-sm mx-2"></i></a>' +
            '<a href="javascript:;" class="text-danger delete-record" data-id="' +
            full['id'] +
            '"><i class="ti ti-trash ti-sm mx-2"></i></a>' +
            // '<a href="javascript:;" class="text-body dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical ti-sm mx-1"></i></a>' +
            // '<div class="dropdown-menu dropdown-menu-end m-0">' +
            // '<a href="javascript:;" class="dropdown-item control">' +
            // 'View Details' +
            // '</a>' +
            // '</div>' +
            '</div>'
          );
        }
      }
    ],
    order: [[4, 'desc']],
    paging: false,
    dom:
      '<"row me-2"' +
      '<"col-md-2"<"me-3"l>>' +
      '<"col-md-10"<"dt-action-buttons text-xl-end text-lg-start text-md-end text-start d-flex align-items-center justify-content-end flex-md-row flex-column mb-3 mb-md-0"fB>>' +
      '>' +
      'r' + // 👈 Added here to enable processing animation
      't' +
      '<"row mx-2"' +
      '<"col-sm-12 col-md-6"i>' +
      '<"col-sm-12 col-md-6"p>' +
      '>',

    language: {
      sLengthMenu: '_MENU_',
      search: '',
      searchPlaceholder: 'Search..'
    },
    // Buttons with Dropdown
    buttons: [
      {
        extend: 'collection',
        className: 'btn btn-label-secondary dropdown-toggle mx-3 waves-effect waves-light',
        text: '<i class="ti ti-screen-share me-1 ti-xs"></i>Export',
        buttons: [
          {
            extend: 'csv',
            text: '<i class="ti ti-file-text me-2" ></i>Csv',
            className: 'dropdown-item',
            exportOptions: {
              columns: [1, 2, 3, 4, 5],
              // prevent avatar to be display
              format: {
                body: function (inner, coldex, rowdex) {
                  if (inner.length <= 0) return inner;
                  var el = $.parseHTML(inner);
                  var result = '';
                  $.each(el, function (index, item) {
                    if (item.classList !== undefined && item.classList.contains('user-name')) {
                      result = result + item.lastChild.firstChild.textContent;
                    } else if (item.innerText === undefined) {
                      result = result + item.textContent;
                    } else result = result + item.innerText;
                  });
                  return result;
                }
              }
            }
          },
          {
            extend: 'excel',
            text: '<i class="ti ti-file-spreadsheet me-2"></i>Excel',
            className: 'dropdown-item',
            exportOptions: {
              columns: [1, 2, 3, 4, 5],
              // prevent avatar to be display
              format: {
                body: function (inner, coldex, rowdex) {
                  if (inner.length <= 0) return inner;
                  var el = $.parseHTML(inner);
                  var result = '';
                  $.each(el, function (index, item) {
                    if (item.classList !== undefined && item.classList.contains('user-name')) {
                      result = result + item.lastChild.firstChild.textContent;
                    } else if (item.innerText === undefined) {
                      result = result + item.textContent;
                    } else result = result + item.innerText;
                  });
                  return result;
                }
              }
            }
          },

          {
            extend: 'copy',
            text: '<i class="ti ti-copy me-2" ></i>Copy',
            className: 'dropdown-item',
            exportOptions: {
              columns: [1, 2, 3, 4, 5],
              // prevent avatar to be display
              format: {
                body: function (inner, coldex, rowdex) {
                  if (inner.length <= 0) return inner;
                  var el = $.parseHTML(inner);
                  var result = '';
                  $.each(el, function (index, item) {
                    if (item.classList !== undefined && item.classList.contains('user-name')) {
                      result = result + item.lastChild.firstChild.textContent;
                    } else if (item.innerText === undefined) {
                      result = result + item.textContent;
                    } else result = result + item.innerText;
                  });
                  return result;
                }
              }
            }
          }
        ]
      }
    ],
    // For responsive popup
    responsive: {
      details: {
        display: $.fn.dataTable.Responsive.display.modal({
          header: function (row) {
            var data = row.data();

            return 'Details of ' + data['customer']['company'];
          }
        }),
        type: 'column',
        renderer: function (api, rowIdx, columns) {
          var dataall = api.data();
          var data = $.map(columns, function (col, i) {
            var result = '';
            //console.log(columns.length + ' : ' + col.columnIndex);

            result =
              result +
              (col.title !== '' // ? Do not show row in modal popup if title is blank (for check box)
                ? '<tr data-dt-row="' +
                  col.rowIndex +
                  '" data-dt-column="' +
                  col.columnIndex +
                  '">' +
                  '<td>' +
                  col.title +
                  ':' +
                  '</td> ' +
                  '<td>' +
                  col.data +
                  '</td>' +
                  '</tr>'
                : '');
            return result;
          }).join('');

          return data ? $('<table class="table"/><tbody />').append(data) : false;
        }
      }
    },
    initComplete: function () {
      // this.api()
      //   .columns(5)
      //   .every(function () {
      //     var column = this;
      //     var select = $(
      //       '<select id="UserRole" class="form-select text-capitalize"><option value=""> Select Role </option></select>'
      //     )
      //       .appendTo('.task_status')
      //       .on('change', function () {
      //         var val = $.fn.dataTable.util.escapeRegex($(this).val());
      //         column.search(val ? '^' + val + '$' : '', true, false).draw();
      //       });
      //     console.log(column.data());
      //     column
      //       .data()
      //       .unique()
      //       .sort()
      //       .each(function (d, j) {
      //         select.append('<option value="' + d + '">' + d + '</option>');
      //       });
      //   });
      // Adding plan filter once table initialized
      this.api()
        .columns(1)
        .every(function () {
          var column = this;
          var select = $('#workCompany').on('change', function () {
            var val = $.fn.dataTable.util.escapeRegex($(this).val());
            column.search(val ? '^' + val + '$' : '', true, false).draw();
          });
        });

      // Adding status filter once table initialized
      this.api()
        .columns(5)
        .every(function () {
          var column = this;
          var select = $(
            '<select id="FilterTransaction" class="form-select text-capitalize status-filter"><option value="" disabled> Select Status </option>' +
              '<option value="Open" selected>Open/Pending</option>' +
              '<option value="Closed">Closed</option>' +
              '<option value="Archived">Archived</option>' +
              '<option value="All">All</option>' +
              '</select>'
          )
            .appendTo('.task_status')
            .on('change', function () {
              var val = $.fn.dataTable.util.escapeRegex($(this).val());
              column.search(val ? '^' + val + '$' : '', true, false).draw();
            });

          // column
          //   .data()
          //   .unique()
          //   .sort()
          //   .each(function (d, j) {
          //     select.append(
          //       '<option value="' + statusObj[d].title + '" class="text-capitalize">' + statusObj[d].title + '</option>'
          //     );
          //   });
        });

      //add butto to reset the filter

      // Add a button to reset the filter
      var resetButton = $('<button class="btn btn-warning ms-2">Reset Filters</button>')
        .appendTo('.task_filter')
        .on('click', function () {
          // Reset the select elements

          $('#FilterTransaction').val('Open').trigger('change');
          $('#workCompany').val('').trigger('change');

          // Redraw the DataTable
          // dt_user.ajax.reload();
        });
    }
  });

  // Show/hide description row
  $('.datatables-tasks tbody').on('click', '.open-record', function () {
    var tr = $(this).closest('tr');
    var row = dt_user.row(tr);

    if (row.child.isShown()) {
      row.child.hide();
      tr.removeClass('shown');
    } else {
      var descriptionHtml = row.data().long_desc || '';
      var $descDiv = $('<div class="p-3 bg-light border rounded"></div>');
      $descDiv.html(descriptionHtml); // Safely inject HTML

      row.child($descDiv).show();
      tr.addClass('shown');
    }
  });
  $('.update-company, .update-status , .status-filter').on('change', function () {
    dt_user.ajax.reload();
  });

  // Delete Record
  $(document).on('click', '.delete-record', function () {
    var id = $(this).data('id'); // Get the ID from the second column (index 1)
    var $row = $(this).closest('tr');
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: false,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!'
    }).then(function (result) {
      if (result.isConfirmed) {
        $.ajax({
          url: '/manage-work-orders/delete/' + id,
          type: 'get',
          data: {
            _token: '{{ csrf_token() }}'
          },
          success: function (response) {
            if (response.status) {
              dt_user.row($row).remove().draw();
              toastr.success(response.message, 'Success', {
                closeButton: true,
                progressBar: true,
                timeOut: 3000,
                positionClass: 'toast-top-right'
              });
              $('.btn-close').click();
            } else {
              toastr.error(response.message, 'Error', {
                closeButton: true,
                progressBar: true,
                timeOut: 3000,
                positionClass: 'toast-top-right'
              });
            }
          },
          error: function () {
            toastr.error('Technical error', 'Error', {
              closeButton: true,
              progressBar: true,
              timeOut: 3500,
              positionClass: 'toast-top-right'
            });
          }
        });
      }
    });
  });

  // Update status
  $(document).on('change', '.update-status', function () {
    var status = $(this).val();
    var id = $(this).data('id'); // Get the ID from the second column (index 1)

    if (status == 'Archived') {
      Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: false,
        confirmButtonText: 'Yes, Archive it!',
        cancelButtonText: 'No, cancel!'
      }).then(function (result) {
        if (result.isConfirmed) {
          changeStatus(id, status);
        } else {
          dt_user.ajax.reload();
        }
      });
    } else {
      changeStatus(id, status);
    }
  });

  function changeStatus(id, status) {
    $.ajax({
      url: '/manage-work-orders/update-status/' + id,
      type: 'get',
      data: {
        id: id,
        status: status,
        _token: '{{ csrf_token() }}'
      },
      success: function (response) {
        // Handle success response
        if (response.status) {
          // Show SweetAlert success message
          toastr.success(response.message, 'Success', {
            closeButton: true,
            progressBar: true,
            timeOut: 2000,
            positionClass: 'toast-top-right'
          });
          dt_user.ajax.reload();
        } else {
          // Show SweetAlert error message
          toastr.error(response.message, 'Error', {
            closeButton: true,
            progressBar: true,
            timeOut: 2000,
            positionClass: 'toast-top-right'
          });
        }
      },
      error: function (xhr, status, error) {
        // Handle error response
        toastr.error('Technical error', 'Error', {
          closeButton: true,
          progressBar: true,
          timeOut: 2000,
          positionClass: 'toast-top-right'
        });
      }
    });
  }
  // Filter form control to default size
  // ? setTimeout used for multilingual table initialization
  setTimeout(() => {
    $('.dataTables_filter .form-control').removeClass('form-control-sm');
    $('.dataTables_length .form-select').removeClass('form-select-sm');
  }, 300);
});
