'use strict';

$(function () {
  $('#siteConstantForm').on('submit', function (e) {
    e.preventDefault(); // Prevent default form submission
    var formData = new FormData(this);

    $.ajax({
      url: '/manage-site-constants',
      type: 'POST',
      data: formData,
      success: function (response) {
        if (response.status) {
          // Show SweetAlert success message
          toastr.success(response.message, 'Success', {
            closeButton: true,
            progressBar: true,
            timeOut: 2000,
            positionClass: 'toast-top-right'
          });
        }
      },
      cache: false,
      contentType: false,
      processData: false,
      error: function (xhr) {
        // Handle error response
        console.log(xhr.responseJSON);
        var errors = xhr.responseJSON.errors;
        if (errors) {
          // Show validation errors
          if (errors.email_template_1) {
            $('#email_template_1').addClass('is-invalid');
            $('#email_template_1')
              .closest('.mb-3')
              .find('.invalid-feedback')
              .html(
                '<div data-field="email_template_1" data-validator="notEmpty">' + errors.email_template_1[0] + '</div>'
              );
          } else {
            // Show SweetAlert error message
            toastr.error(xhr.responseJSON.message, 'Error', {
              closeButton: true,
              progressBar: true,
              timeOut: 3000,
              positionClass: 'toast-top-right'
            });
          }
        } else {
          // Show generic error message

          // 'Something went wrong. Please try again.'
          toastr.error('Something went wrong. Please try again.', 'Error', {
            closeButton: true,
            progressBar: true,
            timeOut: 3000,
            positionClass: 'toast-top-right'
          });
        }
      }
    });
  });
});
