/**
 * Page User List
 */

'use strict';

$(function () {
  $('#create-work-order').on('click', function (e) {
    //get all values from the checkbox checked ,name="checkDevice[]"
    var qb = $('#qb').val();
    var cid = $('#customer_id').val();
    var type = $('#type').val();
    var work_order_id = $('#work_order_id').val();
    var notes = $('#notes').val();
    if (!type) {
      $('#type').addClass('is-invalid');
      $('#type').focus();

      return;
    }
    if (!qb) {
      $('#qb').addClass('is-invalid');
      $('#qb').focus();

      return;
    }
    var selectedDevices = [];
    $('input[name="checkDevice[]"]:checked').each(function () {
      selectedDevices.push($(this).val());
    });
    if (selectedDevices.length === 0) {
      // Show SweetAlert error message
      Swal.fire({
        title: 'Error!',
        text: 'Please select at least one device.',
        icon: 'error',
        customClass: {
          confirmButton: 'btn btn-primary waves-effect waves-light'
        },
        buttonsStyling: false
      });
      return;
    } else {
      // Show SweetAlert confirmation message
      Swal.fire({
        title: 'Are you sure?',
        text: 'You are about to create a work order for the selected devices.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, create it!',
        cancelButtonText: 'No, cancel!',
        customClass: {
          confirmButton: 'btn btn-primary waves-effect waves-light',
          cancelButton: 'btn btn-secondary waves-effect waves-light'
        },
        buttonsStyling: false
      }).then(result => {
        if (result.isConfirmed) {
          $.ajax({
            url: '/manage-work-orders/update',
            type: 'POST',
            data: {
              devices: selectedDevices,
              qb: qb,
              customer_id: cid,
              type: type,
              work_order_id: work_order_id,
              notes: notes,
              _token: $('meta[name="csrf-token"]').attr('content')
            },
            success: function (response) {
              if (response.status) {
                // Show SweetAlert success message
                toastr.success(response.message, 'Success', {
                  closeButton: true,
                  progressBar: true,
                  timeOut: 2000,
                  positionClass: 'toast-top-right'
                });

                // after 2 seconds redirect to manage-work-orders page
                setTimeout(function () {
                  window.location.href = '/manage-work-orders';
                }, 500);
              }
            },
            error: function (xhr, status, error) {
              // Handle error response
              console.log(xhr.responseJSON);
              var errors = xhr.responseJSON.errors;
              if (errors) {
                // Show validation errors
                Swal.fire({
                  title: 'Error!',
                  text: errors[Object.keys(errors)[0]][0],
                  icon: 'error',
                  customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light'
                  },
                  buttonsStyling: false
                });
              } else {
                // Show SweetAlert error message
                Swal.fire({
                  title: 'Error!',
                  text: xhr.responseJSON.message,
                  icon: 'error',
                  customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light'
                  },
                  buttonsStyling: false
                });
              }
            }
          });
        }
      });
    }
  });
});
